package cn.xhuidong.util;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import java.io.IOException;
import java.io.InputStream;

/**
 * @auther huidong
 * @date 2020/2/15 2:28
 */

/**
 * 使用单例模式获取SqlSessionFactory
 */
public class GetSqlSessionFactory {



    private static SqlSessionFactory sqlSessionFactory;

    /**
     * 私有构造方法，使该类不可创建新对象
     */
    private GetSqlSessionFactory(){

    }
    /**
     * 使用同步锁
     * @return sql session 工厂
     */
    synchronized public static SqlSessionFactory getSqlSessionFactory(){
        if (sqlSessionFactory == null){
            //获取资源文件流
            String resource = "SqlMapConfig.xml";
            InputStream inputStream = null;
            try {
                inputStream = Resources.getResourceAsStream(resource);
            } catch (IOException e) {

            }
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        }
        return sqlSessionFactory;
    }
}
