package cn.xhuidong.domain;

import java.io.Serializable;

/**
 * @auther huidong
 * @date 2020/3/1 16:58
 */
public class Animal implements Serializable {
    private int postId;
    private String date;
    private String title;
    private String imgSrc;
    private String content;
    private int collection;
    private int reading;
    private String headImgSrc;
    private String author;
    private String dateTime;
    private String detail;
    private String music;

    public int getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImgSrc() {
        return imgSrc;
    }

    public void setImgSrc(String imgSrc) {
        this.imgSrc = imgSrc;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getCollection() {
        return collection;
    }

    public void setCollection(int collection) {
        this.collection = collection;
    }

    public int getReading() {
        return reading;
    }

    public void setReading(int reading) {
        this.reading = reading;
    }

    public String getHeadImgSrc() {
        return headImgSrc;
    }

    public void setHeadImgSrc(String headImgSrc) {
        this.headImgSrc = headImgSrc;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getMusic() {
        return music;
    }

    public void setMusic(String music) {
        this.music = music;
    }

    @Override
    public String toString() {
        return "Animal{" +
                "postId=" + postId +
                ", date='" + date + '\'' +
                ", title='" + title + '\'' +
                ", imgSrc='" + imgSrc + '\'' +
                ", content='" + content + '\'' +
                ", collection=" + collection +
                ", reading=" + reading +
                ", headImgSrc='" + headImgSrc + '\'' +
                ", author='" + author + '\'' +
                ", dateTime='" + dateTime + '\'' +
                ", detail='" + detail + '\'' +
                ", music='" + music + '\'' +
                '}';
    }
}
