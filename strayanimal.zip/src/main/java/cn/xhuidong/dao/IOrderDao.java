package cn.xhuidong.dao;

import cn.xhuidong.domain.Order;

import java.util.List;

/**
 * @auther huidong
 * @date 2020/2/15 0:39
 */
public interface IOrderDao {

/**
 * 查询所有订单
 */
List<Order> findAll();
}
