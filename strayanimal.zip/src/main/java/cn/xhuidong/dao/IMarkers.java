package cn.xhuidong.dao;

import cn.xhuidong.domain.Markers;

import java.util.List;

/**
 * @auther huidong
 * @date 2020/2/19 0:36
 */
public interface IMarkers {
    List<Markers> findAll();
}
