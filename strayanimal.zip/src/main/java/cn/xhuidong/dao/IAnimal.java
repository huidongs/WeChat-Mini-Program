package cn.xhuidong.dao;

import cn.xhuidong.domain.Animal;

import java.util.List;

/**
 * @auther huidong
 * @date 2020/3/1 17:28
 */
public interface IAnimal {

    List<Animal> findAll();
    void insertAnimal(Animal animal);
}
