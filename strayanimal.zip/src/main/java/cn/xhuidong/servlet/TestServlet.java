package cn.xhuidong.servlet;

import cn.xhuidong.dao.IOrderDao;
import cn.xhuidong.domain.Markers;
import cn.xhuidong.domain.Order;
import cn.xhuidong.util.GetSqlSession;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.mysql.cj.xdevapi.JsonArray;
import org.apache.ibatis.session.SqlSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//可以方便的实现json对象与JavaBean对象的转换，实现JavaBean对象与json字符串的转换，实现json对象与json字符串的转换

public class TestServlet extends javax.servlet.http.HttpServlet {

    private IOrderDao iOrderDao;

    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        //设置编码
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");
//        System.out.println(request.getParameter("postId"));
//        System.out.println(request.getParameter("date"));
//        System.out.println(request.getParameter("title"));
//        System.out.println(request.getParameter("content"));
//        System.out.println(request.getParameter("detail"));
//
//        try {
//            SqlSession sqlSession = GetSqlSession.getSqlSession();
//            //orders = sqlSession.selectOne("cn.xhuidong.dao.IOrderDao.findAll", "");
//            //动态代理对象调用,是根据mapper接口方法的返回值决定,如果返回的是list则调用的是selectList方法,
//            // 如果返回的是单个值或者是对象那么调用的是selectOne方法.
//            iOrderDao = sqlSession.getMapper(IOrderDao.class);
//            List<Order> orders = iOrderDao.findAll();
//            System.out.println(orders);
//            for (Order order : orders) {
//                System.out.println("---------------每个account信息-----------------");
//                System.out.println(order);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//            GetSqlSession.rollback();
//        } finally {
//            GetSqlSession.commit();
//        }
//       Order order = new Order();



//        order.setId(Integer.parseInt(request.getParameter("oid")));
//        order.setName(request.getParameter("oname"));
//        order.setPrice(Double.parseDouble(request.getParameter("oprice")));


//        String[][] markers = {{"1","118.70528","32.577459"},{"2","118.70528","32.177459"}};
//

//        Map<String,String> map1 = new HashMap<>();
//        Map<String,String> map2 = new HashMap<>();
//        Map<String, Map<String, String>> map = new HashMap<>();
//        map1.put("longitude","118.70528");
//        map1.put("latitude","31.377459");
//        map2.put("longitude","118.70528");
//        map2.put("latitude","32.177459");
//        map.put("Location_1",map1);
//        map.put("Location_2",map2);
//
//        System.out.println(map)
       // String jstr = JSON.toJSONString(order);
      //  JSONArray.parseArray(String.valueOf(markers));
//        JSONArray jsonArray;
//        jsonArray = new JSONArray();



//        String jsonArray = JSON.toJSONString(markers);
//        PrintWriter out = response.getWriter();
//        out.println(jsonArray);
//
//        out.flush();
//        out.close();
    }
}