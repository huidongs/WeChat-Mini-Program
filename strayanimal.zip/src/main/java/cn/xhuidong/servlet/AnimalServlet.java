package cn.xhuidong.servlet;

import cn.xhuidong.dao.IAnimal;
import cn.xhuidong.dao.IOrderDao;
import cn.xhuidong.domain.Animal;
import cn.xhuidong.domain.Order;
import cn.xhuidong.util.GetSqlSession;
import com.alibaba.fastjson.JSON;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "AnimalServlet", urlPatterns = "/AnimalServlet")
public class AnimalServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置编码
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");
        List<Animal> animals = null;

        try {
            SqlSession sqlSession = GetSqlSession.getSqlSession();
            //orders = sqlSession.selectOne("cn.xhuidong.dao.IOrderDao.findAll", "");
            //动态代理对象调用,是根据mapper接口方法的返回值决定,如果返回的是list则调用的是selectList方法,
            // 如果返回的是单个值或者是对象那么调用的是selectOne方法.
            IAnimal iAnimal = sqlSession.getMapper(IAnimal.class);
            animals = iAnimal.findAll();
//            System.out.println(animals);
//            for (Animal animal : animals) {
//                System.out.println("---------------每个Animal信息-----------------");
//                System.out.println(animal);
//            }
            /*Animal信息录入操作*/
            if (request.getParameter("postId") != null) {
                Animal animal = new Animal();
                animal.setPostId(Integer.parseInt(request.getParameter("postId")));
                animal.setDate(request.getParameter("date"));
                animal.setTitle(request.getParameter("title"));
                animal.setContent(request.getParameter("content"));
                animal.setDetail(request.getParameter("detail"));
                iAnimal.insertAnimal(animal);
                System.out.println("执行");
            } else {
                System.out.println("未执行");
            }
        } catch (Exception e) {
            e.printStackTrace();
            GetSqlSession.rollback();
        } finally {
            GetSqlSession.commit();
        }
        String jsonArray = JSON.toJSONString(animals);
        PrintWriter out = response.getWriter();
        out.println(jsonArray);
    }
}
