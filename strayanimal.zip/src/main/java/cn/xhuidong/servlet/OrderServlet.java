package cn.xhuidong.servlet;

import cn.xhuidong.dao.IOrderDao;
import cn.xhuidong.domain.Order;
import cn.xhuidong.util.GetSqlSession;
import com.alibaba.fastjson.JSON;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "OrderServlet" ,urlPatterns = "/OrderServlet")
public class OrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置编码
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");

        List<Order> orders=null;
        try {
            SqlSession sqlSession = GetSqlSession.getSqlSession();
            //orders = sqlSession.selectOne("cn.xhuidong.dao.IOrderDao.findAll", "");
            //动态代理对象调用,是根据mapper接口方法的返回值决定,如果返回的是list则调用的是selectList方法,
            // 如果返回的是单个值或者是对象那么调用的是selectOne方法.
            IOrderDao iOrderDao= sqlSession.getMapper(IOrderDao.class);
            orders = iOrderDao.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            GetSqlSession.rollback();
        } finally {
            GetSqlSession.commit();
        }
        String jsonArray = JSON.toJSONString(orders);
        PrintWriter out = response.getWriter();
        out.println(jsonArray);
    }

}
