package cn.xhuidong.servlet;

import cn.xhuidong.dao.IAnimal;
import cn.xhuidong.dao.IMarkers;
import cn.xhuidong.domain.Animal;
import cn.xhuidong.domain.Markers;
import cn.xhuidong.util.GetSqlSession;
import com.alibaba.fastjson.JSON;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "MarkerServlet" ,urlPatterns = "/MarkerServlet")
public class MarkerServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //设置编码
        request.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");
        response.setCharacterEncoding("utf-8");
        List<Markers> markers = null;
        try {
            SqlSession sqlSession = GetSqlSession.getSqlSession();
            IMarkers iMarkers = sqlSession.getMapper(IMarkers.class);
            markers = iMarkers.findAll();
            System.out.println(markers);
        } catch (Exception e) {
            e.printStackTrace();
            GetSqlSession.rollback();
        } finally {
            GetSqlSession.commit();
        }

        String jsonArray = JSON.toJSONString(markers);
        PrintWriter out = response.getWriter();
        out.println(jsonArray);


    }
}

